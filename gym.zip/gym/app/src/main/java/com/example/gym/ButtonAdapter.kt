package com.example.gym

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class ButtonAdapter(private val context: Context, private val buttonList: List<String>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.button_item, parent, false)
        return ButtonViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is ButtonViewHolder) {
            val buttonText = buttonList[position]
            holder.button.text = buttonText

            // Set a click listener for the button
            holder.button.setOnClickListener {
                onButtonClick(buttonText)
            }
        }
    }

    override fun getItemCount(): Int {
        return buttonList.size
    }

    // ViewHolder for button items
    class ButtonViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val button: Button = itemView.findViewById(R.id.button)
    }

    // Function to handle button click
    private fun onButtonClick(buttonText: String) {
        // Handle button click here
        Toast.makeText(context, "Clicked $buttonText", Toast.LENGTH_SHORT).show()
    }
}
