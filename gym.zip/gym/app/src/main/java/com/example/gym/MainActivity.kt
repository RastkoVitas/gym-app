// src/com/example/gym/MainActivity.kt
package com.example.gym

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Sample button data
        val buttonList: MutableList<String> = ArrayList()
        for (i in 1..50) {
            buttonList.add("Button $i")
        }

        // Set up RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Use an object expression to provide behavior for onButtonClick
        val buttonAdapter = ButtonAdapter(this, buttonList)
        recyclerView.adapter = buttonAdapter
    }
}
